<?php
# FileName="Connection_php_mysql.htm"
# Type="MYSQL"
# HTTP="true"
$hostname_CONEXION = "localhost";
$database_CONEXION = "gestion";
$username_CONEXION = "root";
$password_CONEXION = "";
$CONEXION = mysql_pconnect($hostname_CONEXION, $username_CONEXION, $password_CONEXION) or trigger_error(mysql_error(),E_USER_ERROR); 
?>